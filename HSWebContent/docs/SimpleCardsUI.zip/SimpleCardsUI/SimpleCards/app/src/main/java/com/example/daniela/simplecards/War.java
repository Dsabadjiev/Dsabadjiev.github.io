/*@author: Daniel Abadjiev
 * @date: 5/29/18
 * This is a class to play the card game War. This is the original version, which was later redone.
 */
package com.example.daniela.simplecards;
import android.widget.TextView;

import java.util.*;
public class War implements Game{
	//This is the main method I thought I needed, but realized I would use a runner class.

	public static void main(String[] args) {
		//This ended up being in the runner class.
//		Deck deck=new Deck();
//		Hand player1=deck.subHand(0, deck.getSize()/2, "p1");
//		Hand player2=deck.subHand(deck.getSize()/2, deck.getSize(), "p2");
////		ArrayList<Card> p1Cards=new ArrayList<Card>(), p2Cards=new ArrayList<Card>();
//		txtOutput.setText(txtOutput.getText()+"\nnew War().play()+" has won the game.");
		
		

	}
	//This is the method to play a game of war.
	public  String play(TextView txtOutput){
		Deck deck=new Deck();
		deck.shuffle();
		Hand p1=deck.subHand(0, deck.getSize()/2, "p1");
		Hand p2=deck.subHand(deck.getSize()/2, deck.getSize(), "p2");
		Hand table=new Hand(new ArrayList<Card>(), "table");
		p1.shuffle();
		p2.shuffle();

		txtOutput.setText(txtOutput.getText()+"\n"+p1.getName()+" has "+p1.getSize()+" cards.");
		txtOutput.setText(txtOutput.getText()+"\n"+p2.getName()+" has "+p2.getSize()+" cards.");
		while (p1.getSize()>0 && p2.getSize()>0){
			txtOutput.setText(txtOutput.getText()+"\n"+p1.getName()+" plays "+p1.cardAt(0)+
					" and "+p2.getName()+" plays "+p2.cardAt(0));
			
			exchangeCards(p1, p2, table, txtOutput);
//			Hand.switchCard(p1, p2, p2.cardAt(0));
			System.out.print("Now ");
			txtOutput.setText(txtOutput.getText()+"\n"+p1.getName()+" has "+p1.getSize()+" cards.");
			txtOutput.setText(txtOutput.getText()+"\n"+p2.getName()+" has "+p2.getSize()+" cards.");
			p1.shuffle();
			p2.shuffle();
		}
		Hand winner;
		if (p1.getSize()>0)
			winner=p1;
		else
			winner=p2;
		return winner.getName();
//		txtOutput.setText(txtOutput.getText()+"\n"+winner.getName()+" has won the game!");
// I put this above.
	}
	//This is the method to exchange cards between to players via war rules.
	public static void exchangeCards(Hand p1, Hand p2, Hand table, TextView txtOutput){
		if (p1.cardAt(0).compareTo(p2.cardAt(0))>0){
			Hand.switchCard(p1, p2, p2.cardAt(0));
			Hand.switchCards(p1, table);
			txtOutput.setText(txtOutput.getText()+"\n"+p1.getName()+" won the round");
		}
		else if (p1.cardAt(0).compareTo(p2.cardAt(0))<0){
			Hand.switchCard(p2, p1, p1.cardAt(0));
			Hand.switchCards(p2, table);
			txtOutput.setText(txtOutput.getText()+"\n"+p2.getName()+" won the round");
		}
		else{
			if (p1.getSize()<6)
				Hand.switchCards(p2,  p1);
			else if (p2.getSize()<6)
				Hand.switchCards(p1, p2);
			else{
			for (int i=0; i<4; i++){
				Hand.switchCard(table, p1, p1.cardAt(i));
				Hand.switchCard(table, p2, p2.cardAt(i));
			}
			exchangeCards(p1, p2, table, txtOutput);
			}
		}
		
	}
	//This did not seem viable as a way to do this before, I did the implementation of the game
	// with a subsequent version of this method in a later version.
//	public static void round(Hand p1, Hand p2){
//		txtOutput.setText(txtOutput.getText()+"\np1.getName()+" has "+p1.getSize()+" cards.");
//		txtOutput.setText(txtOutput.getText()+"\np2.getName()+" has "+p2.getSize()+" cards.");
//		while (p1.getSize()>0 && p2.getSize()>0){
//			txtOutput.setText(txtOutput.getText()+"\np1.getName()+" plays "+p1.cardAt(0)+" and "
// +p2.getName()+" plays "+p2.cardAt(0));
//			Hand.switchCard(p1, p2, p2.cardAt(0));
//			System.out.print("Now ");
//			txtOutput.setText(txtOutput.getText()+"\np1.getName()+" has "+p1.getSize()+" cards.");
//			txtOutput.setText(txtOutput.getText()+"\np2.getName()+" has "+p2.getSize()+" cards.");
//		}
//		Hand winner;
//		if (p1.getSize()>0)
//			winner=p1;
//		else
//			winner=p2;
//		txtOutput.setText(txtOutput.getText()+"\nwinner.getName()+" has won the game!");
//		
//	}

}
