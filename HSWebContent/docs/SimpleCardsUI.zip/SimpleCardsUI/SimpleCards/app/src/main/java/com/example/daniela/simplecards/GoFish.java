/*@author: Daniel Abadjiev
 * @date: 6/10/18
 * This is the object used for playing game.
 */
package com.example.daniela.simplecards;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.*;

public class GoFish implements Game {
    private ArrayList<Hand> players=new ArrayList<Hand>();
    TextView output, viewCards;
    EditText inputName, inputCard;
    Deck deck=new Deck();
    Hand table;
    int numPlayers, playerAtTurn;
    Button next;
    Button swich;
    //This is the constructor which takes in the ArrayList of players.
    public GoFish(ArrayList<Hand> hands, TextView out, EditText in1, EditText in2,
                  TextView viewCards, Button next, Button swich){
        players=hands;
        output=out;
        inputName=in1;
        inputCard=in2;
        this.viewCards=viewCards;
        this.next=next;
        this.swich=swich;

    }
    //This is the constructor which takes in the number of players and gives default names.
    public GoFish(TextView out, EditText in1,EditText in2, int numPlay, TextView viewCards,
                  Button next, Button swich){
        output=out;
        inputName=in1;
        inputCard=in2;
        deck.shuffle();
//        out.append("Go Fish?!?!"); Testing purposes
        numPlayers=numPlay;
        if (numPlayers<7) {
            for (int i = 0; i < numPlayers; i++)
                players.add(deck.subHand(i*7, (i+1)*7, ("Player "+(i+1))));
            table=deck.subHand(numPlayers*7, deck.getSize(), "table");
        }
        else{
            int numCards=52/numPlayers;
            for (int i = 0; i < numPlayers; i++)
                players.add(deck.subHand(i*numCards, (i+1)*numCards, ("Player "+(i+1))));
            table=deck.subHand(numPlayers*numCards, deck.getSize(), "table");
        }
        this.viewCards=viewCards;
        this.next=next;
        this.swich=swich;
    }
    //This is the constructor which takes in an ArrayList with the names of the players
    public GoFish(TextView out, EditText in1,EditText in2, ArrayList<String> names,
                  TextView viewCards, Button next, Button swich){

        output=out;
        inputName=in1;
        inputCard=in2;
        deck.shuffle();
        numPlayers=names.size();
        if (numPlayers<7) {
            for (int i = 0; i < numPlayers; i++)
                players.add(deck.subHand(i*7, (i+1)*7, (names.get(i))));
            table=deck.subHand(numPlayers*7, deck.getSize(), "table");

        }
        else{
            int numCards=52/numPlayers;
            for (int i = 0; i < numPlayers; i++)
                players.add(deck.subHand(i*numCards, (i+1)*numCards, (names.get(i))));
            table=deck.subHand(numPlayers*numCards, deck.getSize(), "table");
        }
        this.viewCards=viewCards;
        this.next=next;
        this.swich=swich;
    }
    //These are the getters for table and players.
    public Hand getTable() {
        return table;
    }

    public ArrayList<Hand> getPlayers() {
        return players;
    }
    //This method sees if the game has a winner, and returns it if exists, null otherwise.
    public Hand findWinner(){
        for (int i=0; i<players.size(); i++){
            if (players.get(i).getSize()==0)
                return players.get(i);
        }
        return null;
    }
    //This is the method to play a game of go fish.
    public String play(TextView out){
        output=out;
        out.setText("Now you are playing Go Fish! Proceed with the Next button and follow directions.");
        output.append("\nA set is 4 cards of the same value. Hit next again to get rid of a set.");
        out.append("\nNote when entering cards:\nPlease enter the cards in the form \"[value] of [suit]\". ");
        out.append("\nFor example,\"Ace of Hearts\" or \"2 of Clubs\"");
        out.append("\nValid suits are Spades, Hearts, Diamonds, and Clubs");
        out.append("\nValid values can either be an integer (1 is ace, King is 13)");
        out.append("\nor \"Ace\" or \"Queen\", \"King\", or \"Jack\".");
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            //This sets the method for what happens when the button next is clicked.
            public void onClick(View view) {
                if (findWinner()==null) {
                    removePairs(players.get(playerAtTurn));
                    output.append("\nEnter the player being asked and the card " +
                            players.get(playerAtTurn).getName() + " is asking for, then hit switch.");
                    InteractiveWar.scrollDown(output);
                    inputName.setText("Player 0");
                    inputCard.setText("<Enter the card>");
                    viewCards.setVisibility(View.VISIBLE);
                    viewCards.setText(players.get(playerAtTurn).getName()+" has "+
                            players.get(playerAtTurn).toString());

                }
                else{
                    output.append("The winner is "+findWinner().getName());
                }

            }
        });

        swich.setOnClickListener(new View.OnClickListener() {
            @Override
            //This sets the method for what happens when the button swich is clicked.
            public void onClick(View view) {

                String name=inputName.getText().toString();
                String sCard=inputCard.getText().toString();
                Hand target=Hand.findPlayer(name, players);
                if (null==target || target.equals(players.get(playerAtTurn))){
                    if (null != target && target.equals(players.get(playerAtTurn)))
                        output.append("\nYou can't ask yourself.");
                    output.append("\nPlease enter a valid player name");
                    InteractiveWar.scrollDown(output);
                    return;
                }
                if (!Card.isValidCard(sCard)){
                    output.append("\nPlease enter a valid card");
                    InteractiveWar.scrollDown(output);
                    return;
                }

                viewCards.setVisibility(View.INVISIBLE);


                Card cardToSwitch=new Card(sCard);
                boolean switched=Hand.switchCard(players.get(playerAtTurn), target, cardToSwitch);
                if (switched) {
                    output.append("\n" + players.get(playerAtTurn).getName() +
                            " got the " + cardToSwitch + " from " + target.getName());
                    InteractiveWar.scrollDown(output);
                }
                else{
                    output.append("\nGO FISH!");
                    InteractiveWar.scrollDown(output);
                    if (table.getSize()>0)
                        Hand.switchCard(players.get(playerAtTurn), table, table.getCards().get(0));
                    playerAtTurn=players.indexOf(target);
                }
                output.append("\nNow hit next to proceed.");

                

            }
        });
        return "";

    }
    //This is a method to remove the sets from a player, does nothing if no sets exist.
    public static void removePairs(Hand h){
        ArrayList<Integer> matches=new ArrayList<Integer>();
        for (int i=0; i<h.getSize(); i++){
            matches=new ArrayList<Integer>();
            matches.add(i);
            Card cardToCheck=h.getCards().get(i);
            for (int j=0; j<h.getSize(); j++){
                if (j!=i && h.getCards().get(j).getValue()==cardToCheck.getValue())
                    matches.add(j);

            }
            if (matches.size()==4){
                h.removeCard(h.getCards().get(matches.get(3)));
                h.removeCard(h.getCards().get(matches.get(2)));
                h.removeCard(h.getCards().get(matches.get(1)));
                h.removeCard(h.getCards().get(matches.get(0)));

            }
        }
    }




}
