In this folder is my android project.
It can be run in android studio by opening the SimpleCards File (Android project) in this zip file
in android studio.
The version of SDK installed in the tablets in the CS room is good to run my app.
The app can be run by connecting the tablet to the computer via a USB cable and using the run menu (Run app).
All dependencies/files the project needs are in the zip file.
The version of android studio I used was Android Studio 3.2.1
Build #AI-181.5540.7.32.5056338, built on October 8, 2018
JRE: 1.8.0_152-release-1136-b06 amd64
JVM: OpenJDK 64-Bit Server VM by JetBrains s.r.o
on Windows 10 10.0