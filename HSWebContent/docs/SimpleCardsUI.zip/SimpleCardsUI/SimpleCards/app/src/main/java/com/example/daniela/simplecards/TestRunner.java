/*@author:Daniel Abadjiev
 * @date: 5/23/18
 * This is the runner class to test out the basic functionality of cards, hands, and deck.
 * There is a lot of code commented out, as I wanted to test out specific things.
 */
package com.example.daniela.simplecards;
import java.util.*;
public class TestRunner {
	//Since this class is for eclipse, this is the main method to test functionality of Card, Hand,
	//and Deck
	public static void main(String[] args) {
//		Scanner console=new Scanner(System.in);
		Scanner console=new Scanner("h1\nJack of Hearts\n n \nh2\nJack of Hearts\ny\nAce of Diamonds\n n");
		Card ace=new Card("Ace of Hearts");
		System.out.println(ace.getSuit()+", "+ace.getValue());
		System.out.println(ace.getStringValue());
		ArrayList<Card> cards=new ArrayList<Card>();
		cards.add(null);
		cards.add(ace);
//		System.out.println(cards.indexOf(ace));
		cards.add(new Card("Jack of Hearts"));
		
		Hand c=new Hand(cards, "name");
		System.out.println(c);
		c.shuffle();
		System.out.println(c);
//		Hand h1=new Hand(console);
//		Hand h2=new Hand(console);
//		System.out.println(h1+", "+ h2);
////		System.out.println(h2.getCards().get(0).getSuit());
////		System.out.println(h2.indexOf(new Card("Jack of Hearts")));
//		System.out.println(Hand.switchCard(h1, h2, new Card("Queen of Hearts")));
//		System.out.println(h1+", "+ h2);
	}

}
