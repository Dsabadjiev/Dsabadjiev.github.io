/*@author: Daniel Abadjiev
 * @date: 6/5/18
 * This is the main class that opens on start, and which calls other runner classes.
 */
package com.example.daniela.simplecards;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    //This is the equivalent of the main method. It is where execution starts when the application opens.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    //This makes the corresponding button open the activity for simple war
    public void simpleWar(View v){
        Intent scrollWar=new Intent(this, ScrollingActivity.class);
        startActivity(scrollWar);
    }
    //This makes the corresponding button open the activity for interactive war
    public void interactiveWar(View v){
        Intent intWar=new Intent(this, InteractiveWar.class);
        startActivity(intWar);
    }
    //This makes the corresponding button open the activity for animated war
    public void animatedWar(View v){
        Intent aniWar=new Intent(this, AnimatedWar.class);
        startActivity(aniWar);
}
    //This makes the corresponding button open the activity for go fish
    public void goFish(View v){
        Intent goFishy=new Intent(this, MainGoFish.class);
        startActivity(goFishy);
    }
    //This makes the corresponding button open the activity for simple table
    public void simpleTable(View v){
        Intent simplTbley=new Intent(this, SimpleTable.class);
        startActivity(simplTbley);
    }


}
