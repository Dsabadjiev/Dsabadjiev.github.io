package com.example.daniela.simplecards;

//import android.app.ActionBar;
import android.annotation.SuppressLint;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.graphics.Point;
import android.graphics.PointF;
import android.media.Image;
import android.os.Parcelable;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import android.view.ViewParent;
import android.widget.Button;
import android.widget.Gallery;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.LineNumberReader;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class SimpleTable extends AppCompatActivity {

    /**
     * The {@link android.support.v4.view.PagerAdapter} that will provide
     * fragments for each of the sections. We use a
     * {@link FragmentPagerAdapter} derivative, which will keep every
     * loaded fragment in memory. If this becomes too memory intensive, it
     * may be best to switch to a
     * {@link android.support.v4.app.FragmentStatePagerAdapter}.
     */
    protected static Deck deck=new Deck();
    private SectionsPagerAdapter mSectionsPagerAdapter;

    /**
     * The {@link ViewPager} that will host the section contents.
     */
    private ViewPager mViewPager;
    //From copied code
//    ArrayList<String> str = new ArrayList<String>();
//    boolean chageImage = false;
//    int setPos;
    //end copied code
    public LinearLayout otherPlayers;
    public static final int NUMPAGES=4;
    public static ArrayList<Hand> players;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_table);


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.
        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);
        TabLayout tabs = (TabLayout) findViewById(R.id.tabs);

//        tabs.setupWithViewPager(mViewPager);
//        tabs.addTab(tabs.newTab().setText("TESest")); This was for testing purposes, it led me to
        //find out that the .setupWIthViewPager redefines the TabItems in tabs
        tabs.setupWithViewPager(mViewPager);
        //3 is currently a hardcoded number, will change later?
//        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
        for (int i=1; i<NUMPAGES; i++){
            tabs.getTabAt(i).setText("Player "+(i+1));
        }
        tabs.getTabAt(0).setText("Player Long NAMEEE");
        players=new ArrayList<Hand>();
        setPlayers(players);
//        otherPlayers=findViewById(R.id.otherPlayers);
//        for (int j=1; j<=1; j++){
//            ImageView i = new ImageView(this);
//            i.setImageResource(R.drawable.blue_back);
//
//            // set the ImageView bounds to match the Drawable's dimensions
//            i.setAdjustViewBounds(true);
////        i.setLayoutParams(new Gallery.LayoutParams(LayoutParams.WRAP_CONTENT,
////                LayoutParams.WRAP_CONTENT));
//
//            // Add the ImageView to the layout and set the layout as the content view
////            otherPlayers.addView(i);
//        }
//        ImageView i = new ImageView(this);
//        i.setImageResource(R.drawable.blue_back);
//
//        // set the ImageView bounds to match the Drawable's dimensions
//        i.setAdjustViewBounds(true);
////        i.setLayoutParams(new Gallery.LayoutParams(LayoutParams.WRAP_CONTENT,
////                LayoutParams.WRAP_CONTENT));
//
//        // Add the ImageView to the layout and set the layout as the content view
////            otherPlayers.addView(i);
//        mSectionsPagerAdapter.setsOtherPlayers(otherPlayers);
//        mSectionsPagerAdapter.addImage(i);
        Button butMaybe=findViewById(R.id.button10mreep);
        Button back=findViewById(R.id.backButton);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent main=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(main);
            }
        });
//        butMaybe.setOnClickListener(
//                new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//
//                        for (int j=1; j<=1; j++){
//                            ImageView i = new ImageView(getApplicationContext());
//                            i.setImageResource(R.drawable.blue_back);
//
//                            // set the ImageView bounds to match the Drawable's dimensions
//                            i.setAdjustViewBounds(true);
////        i.setLayoutParams(new Gallery.LayoutParams(LayoutParams.WRAP_CONTENT,
////                LayoutParams.WRAP_CONTENT));
//
//                            // Add the ImageView to the layout and set the layout as the content view
////            otherPlayers.addView(i);
//                        }
//                    }
//                }
//        );


//            @Override
//            public void onPageSelected(int position) {
//                Log.i("TAG", "pos::" + position);
//
//            }
//            @Override
//            public void onPageScrollStateChanged(int state) {
//                // TODO Auto-generated method stub
//                int currentPage = mViewPager.getCurrentItem();
//                int currentState=mViewPager.getMeasuredState();
//                int previousState;
//                Log.i("TAG", "currentPage::" + currentPage);
//                Log.i("TAG", "currentState::" + currentState);
//                Log.i("TAG", "previousState::" + previousState);
//                if (currentPage == 4 || currentPage == 0) {
//                    previousState = currentState;
//                    currentState = state;
//                    if (previousState == 1 && currentState == 0) {
//                        pager.setCurrentItem(currentPage == 0 ? 4 : 0);
//                    }
//                }
//
//            }
//
//
//        });

        //The following code was taken from the website
        // https://stackoverflow.com/questions/21368693/how-to-do-circular-scrolling-on-viewpager
//        str.add("3");         // added the last page to the frist
//        str.add("1");        // First item to display in view pager
//        str.add("2");
//        str.add("3");// last item to display in view pager
//        str.add("1");      // added the first page to the last
//        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener()
//        {
//
//            @Override
//            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels)
//            {
//                if (position == str.size() - 1)
//                {
//                    chageImage = true;
//                    setPos = 1;
//                } else if (position == 0)
//                {
//                    chageImage = true;
//                    setPos = str.size() - 2;
//                } else
//                {
//                    chageImage = false;
//                }
//            }
//
//            @Override
//            public void onPageSelected(int position)
//            {
//            }
//
//            @Override
//            public void onPageScrollStateChanged(int state)
//            {
//                if (state == ViewPager.SCROLL_STATE_IDLE && chageImage)
//                {
//                    mViewPager.setCurrentItem(setPos, false);
//                }
//            }
//        });



        //End copied code

//        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });

//        getApplicationContext(); //useless statement

    }
    public static void setPlayers(ArrayList<Hand> players){
        Deck deck=new Deck();
//        players.add(deck);
        players.add(deck.subHand(2,15, "yup"));
        players.add(deck.subHand(3,7,"second"));
        for (int i=3; i<=NUMPAGES; i++)
            players.add(deck.subHand(21,27,"standard"));
    }
    public void onClickMaybe(View v){

    }
    public static boolean closeEnough(int[] location1, int[] location2){
        return Math.abs(location1[0]-location2[0])<=5 &&Math.abs(location1[0]-location2[0])<=5;
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
            getMenuInflater().inflate(R.menu.menu_simple_table, menu);
        return true;
}

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * A placeholder fragment containing a simple view.
     */
    public static class PlaceholderFragment extends Fragment {
        /**
         * The fragment argument representing the section number for this
         * fragment.
         */
        private static final String ARG_SECTION_NUMBER = "section_number";
        private Context context;
        private LinearLayout sOtherPlayers;
        public PlaceholderFragment() {

        }

        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        public static PlaceholderFragment newInstance(int sectionNumber) {
            PlaceholderFragment fragment = new PlaceholderFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
//            args.putParcelable("Application_Context", context);
            fragment.setArguments(args);
//            context=c;
//            sOtherPlayers=l;
            return fragment;
        }

        @SuppressLint("ClickableViewAccessibility")
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_simple_table, container, false);
            TextView textView = (TextView) rootView.findViewById(R.id.section_label);
            textView.setText(getString(R.string.section_format, getArguments().getInt(ARG_SECTION_NUMBER)));
            mainLayout=(ConstraintLayout) rootView.findViewById(R.id.main);
            int playerAtTurn=(getArguments().getInt(ARG_SECTION_NUMBER))-1;
//            playerAtTurn--;

            sOtherPlayers=(LinearLayout) rootView.findViewById(R.id.otherPlayers);
            //copied code from android developer tutorial
            // Instantiate an ImageView and define its properties
//            context=getArguments().getParcelable("Application_Context");
            context=getActivity();
            ArrayList<ImageView> otherCards=new ArrayList<ImageView>();
            for (int j=1; j<=NUMPAGES-1; j++){
                ImageView i = new ImageView(context);
                i.setImageResource(R.drawable.blue_back);

                // set the ImageView bounds to match the Drawable's dimensions
                i.setAdjustViewBounds(true);
    //        i.setLayoutParams(new Gallery.LayoutParams(LayoutParams.WRAP_CONTENT,
    //                LayoutParams.WRAP_CONTENT));
    //
    //            // Add the ImageView to the layout and set the layout as the content view
                otherCards.add(i);
                sOtherPlayers.addView(i);


            }
            otherCards.add(playerAtTurn,null);
            LinearLayout table=(LinearLayout) rootView.findViewById(R.id.table);
            ImageView deckImg=new ImageView(getActivity()), trashImg=new ImageView(getActivity());
            deckImg.setImageResource(R.drawable.blue_back);
            trashImg.setImageResource(R.drawable.gray_back);
            table.addView(deckImg);
            table.addView(trashImg);
//            GestureDetectorCompat gestureDetector=new GestureDetectorCompat(getActivity(), new MyGestureListener());
//            gestureDetector.setOnDoubleTapListener(new GestureDetector.OnDoubleTapListener() {
//                @Override
//                public boolean onSingleTapConfirmed(MotionEvent e) {
//                    return false;
//                }
//
//                @Override
//                public boolean onDoubleTap(MotionEvent e) {
//                    deckImg.setImageResource(R.drawable.c2c);
//                    return false;
//                }
//
//                @Override
//                public boolean onDoubleTapEvent(MotionEvent e) {
//                    deckImg.setImageResource(R.drawable.c2d);
//                    return false;
//                }
//            });
//            deckImg.setOnTouchListener(gestureDetector);


            LinearLayout thisCards=(LinearLayout) rootView.findViewById(R.id.cardsNo);
//            ImageView i = new ImageView(context);
////            players.get(playerAtTurn).getCards().get(0).getCardPic();
//            i.setImageResource(R.drawable.blue_back);
//            thisCards.addView(i);
//            playerAtTurn--;
            players.get(playerAtTurn);
            textView.append(" size is "+players.get(playerAtTurn).getCards().size());
            HorizontalScrollView thisCardsScroller=(HorizontalScrollView) rootView.findViewById(R.id.scrollCards);

            //I want to get the width of the whole screen
            Display display=getActivity().getWindowManager().getDefaultDisplay();
            Point p=new Point();
            display.getSize(p);
            int width=p.x;
            ArrayList<ImageView> totalCards=new ArrayList<ImageView>();
            ArrayList<CardWithImage> playersCardWithImage=new ArrayList<CardWithImage>();
            updateScreen(thisCards,width, context, playerAtTurn, mainLayout,textView,totalCards, otherCards, playersCardWithImage);
            deckImg.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    textView.append(deck.getCards().get(0).toString()+" got added to this player's hand");
                    players.get(playerAtTurn).addCard(deck.getCards().get(0));
                    deck.getCards().remove(deck.getCards().get(0));
                    updateScreen(thisCards,width, context, playerAtTurn, mainLayout, textView, totalCards, otherCards, playersCardWithImage);
                    //copied code from https://stackoverflow.com/questions/20702333/refresh-fragment-at-reload
//                    android.support.v4.app.FragmentTransaction ft = getFragmentManager().beginTransaction();
//                    ft.detach(getParentFragment()).attach(getParentFragment()).commit();
                    //end copied code
                    return false;
            }
            });
            Button buttonShuffle=(Button) rootView.findViewById(R.id.shuffle);
            buttonShuffle.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    deck.shuffle();
                }
            });
//            //Note, the following button was for testing purposes, and is now hidden on the screen.
//            Button button=(Button) rootView.findViewById(R.id.button10mreep);
//            button.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    ImageView i2 = new ImageView(context);
//                    i2.setImageResource(R.drawable.purple_back);
//
//                    // set the ImageView bounds to match the Drawable's dimensions
//                    //I will need to readjust dimensions later to
//                    i2.setAdjustViewBounds(true);
////        i.setLayoutParams(new Gallery.LayoutParams(LayoutParams.WRAP_CONTENT,
////                LayoutParams.WRAP_CONTENT));
////
////            // Add the ImageView to the layout and set the layout as the content view
////            try {
//                    sOtherPlayers.addView(i2);
////
//                }
//            });




            return rootView;
        }
        @SuppressLint("ClickableViewAccessibility")
        public static void updateScreen(ViewGroup thisCards, int width, Context context,
                                        int playerAtTurn, ViewGroup mainLayout, TextView textView,
                                        ArrayList<ImageView> totalCards, ArrayList<ImageView> otherCards,
                                        ArrayList<CardWithImage> playersCardWithImage){
            thisCards.removeAllViews();

            for (int i=0; i<totalCards.size(); i++)
                if ((ViewGroup) totalCards.get(i).getParent()!=null)
                ((ViewGroup) totalCards.get(i).getParent()).removeView(totalCards.get(i));
            for (int j=0; j<players.get(playerAtTurn).getCards().size(); j++) {
                ImageView cardImage=new ImageView(context);
                cardImage.setImageResource(players.get(playerAtTurn).getCards().get(j).getCardPic());
                players.get(playerAtTurn).getCards().get(j).setImg(cardImage);

                CardWithImage cardImages2=new CardWithImage(players.get(playerAtTurn).getCards().get(j), cardImage);
                playersCardWithImage.add(cardImages2);

                // set the ImageView bounds to match the Drawable's dimensions
                cardImage.setAdjustViewBounds(true);
//                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(10+width/(players.get(playerAtTurn).getSize()), 200);
//                cardImage.setLayoutParams(layoutParams);
                cardImage.setMaxWidth(width/players.get(playerAtTurn).getSize());
                //        i.setLayoutParams(new Gallery.LayoutParams(LayoutParams.WRAP_CONTENT,
                //                LayoutParams.WRAP_CONTENT));
                //
                //            // Add the ImageView to the layout and set the layout as the content view
                //            try {
//                thisCards.removeView(i);
//                cardImage.setOnTouchListener(onTouchListener());
                //copied code from https://stackoverflow.com/questions/16557076/how-to-smoothly-move-a-image-view-with-users-finger-on-android-emulator
                cardImage.setOnTouchListener(new View.OnTouchListener()
                {
                    PointF DownPT = new PointF(); // Record Mouse Position When Pressed Down
                    PointF StartPT = new PointF(); // Record Start Position of 'img'

                    @Override
                    public boolean onTouch(View v, MotionEvent event)
                    {
                        switch (event.getAction())
                        {
                            case MotionEvent.ACTION_MOVE :
                                cardImage.setX((int)(StartPT.x + event.getX() - DownPT.x));
                                cardImage.setY((int)(StartPT.y + event.getY() - DownPT.y));
                                StartPT.set( cardImage.getX(), cardImage.getY() );


                                break;
                            case MotionEvent.ACTION_DOWN :
                                DownPT.set( event.getX(), event.getY() );
                                float x=cardImage.getX(), y=cardImage.getY();
                                StartPT.set( x, y );
                                ((ViewGroup)cardImage.getParent()).removeView(cardImage);
                                totalCards.add(cardImage);
                                mainLayout.addView(cardImage);
                                cardImage.setX(x);
                                cardImage.setY(y);
                                break;
                            case MotionEvent.ACTION_UP :
                                // Nothing have to do

                                int[] out1=new int[2];
                                cardImage.getLocationInWindow(out1);
                                for (int i=0; i<NUMPAGES; i++) {
                                    if (otherCards.get(i)!=null) {
                                        int[] out2 = new int[2];
                                        otherCards.get(i).getLocationInWindow(out2);
                                        if (closeEnough(out1,out2)) {
                                            textView.append("Player "+(i+1)+" needs this card now.");
                                            Card cardToExchange=findByImage(playersCardWithImage,cardImage);
                                            //the next three lines of code are the problem
//                                            Hand.switchCard(players.get(i),players.get(playerAtTurn),cardToExchange);
//                                            players.get(i).addCard(cardToExchange);
//                                            players.get(playerAtTurn).removeCard(cardToExchange);
                                        }
                                    }
                                }
                                break;


                            default :
                                break;
                        }
                        return true;
                    }


                });
                //end copied code
                thisCards.addView(cardImage);
//                ImageView i = new ImageView(context);
//////            players.get(playerAtTurn).getCards().get(0).getCardPic();
//                i.setImageResource(R.drawable.blue_back);
//                // set the ImageView bounds to match the Drawable's dimensions
//                i.setAdjustViewBounds(true);
//                        i.setLayoutParams(new Gallery.LayoutParams(LayoutParams.WRAP_CONTENT,
//                                LayoutParams.WRAP_CONTENT));
//                thisCards.addView(i);
            }
        }
        public static Card findByImage(ArrayList<CardWithImage> cardWithImages, ImageView cardImage){
            for (int i=0; i<cardWithImages.size(); i++){
                if (cardImage.equals(cardWithImages.get(i)))
                    return cardWithImages.get(i).getC();
            }
            return null;
        }
        //Copied code from https://developer.android.com/training/gestures/detector#detect

//       I don't think this is necessary, and doesn't seem to do anything
// @Override
//        public boolean onTouchEvent(MotionEvent event){
//            this.mDetector.onTouchEvent(event);
//            return super.onTouchEvent(event);
//        }

//        public class MyGestureListener extends GestureDetector.SimpleOnGestureListener
//                implements View.OnTouchListener {
//            private static final String DEBUG_TAG = "Gestures";
//
//            @Override
//            public boolean onDown(MotionEvent event) {
//                Log.d(DEBUG_TAG,"onDown: " + event.toString());
//                return true;
//            }
//
//
//            @Override
//            public boolean onDoubleTapEvent(MotionEvent event) {
//                Log.d(DEBUG_TAG, "onDoubleTapEvent: " + event.toString());
//                return true;
//                //end copied code
//            }
//
//            //copied code from above
//            PointF DownPT = new PointF(); // Record Mouse Position When Pressed Down
//            PointF StartPT = new PointF(); // Record Start Position of 'img'
//
//            @Override
//            public boolean onTouch(View v, MotionEvent event)
//            {
//                switch (event.getAction())
//                {
//                    case MotionEvent.ACTION_MOVE :
//                        v.setX((int)(StartPT.x + event.getX() - DownPT.x));
//                        v.setY((int)(StartPT.y + event.getY() - DownPT.y));
//                        StartPT.set( v.getX(), v.getY() );
//
//
//                        break;
//                    case MotionEvent.ACTION_DOWN :
//                        DownPT.set( event.getX(), event.getY() );
//                        float x=v.getX(), y=v.getY();
//                        StartPT.set( x, y );
//                        ((ViewGroup)v.getParent()).removeView(v);
//                        mainLayout.addView(v);
//                        v.setX(x);
//                        v.setY(y);
//                        break;
//                    case MotionEvent.ACTION_UP :
//                        // Nothing have to do
//                        break;
//
//
//                    default :
//                        break;
//                }
//                return true;
//            }
//            //end copied code
//
//
//        }

        public void onClickMe(View v){

        }
        private ViewGroup mainLayout;
//        //Copied code from http://www.devexchanges.info/2015/03/simple-moving-object-with-touch-events.html
//        //code was changed a lot to match what I want to do
//        private int xDelta, yDelta;

//        private View.OnTouchListener onTouchListener() {
//            return new View.OnTouchListener() {
//
//                @SuppressLint("ClickableViewAccessibility")
//                @Override
//                public boolean onTouch(View view, MotionEvent event) {
//
//                    final int x = (int) event.getRawX();
//                    final int y = (int) event.getRawY();
//
//                    switch (event.getAction() & MotionEvent.ACTION_MASK) {
//
//                        case MotionEvent.ACTION_DOWN:
//
//                            LinearLayout.LayoutParams lParams = (LinearLayout.LayoutParams)
//                                    view.getLayoutParams();
//
//                            xDelta = x - lParams.leftMargin;
//                            yDelta = y - lParams.topMargin;
//                            break;
//
//                        case MotionEvent.ACTION_UP:
//                            Toast.makeText(getActivity(),
//                                    "thanks for new location!", Toast.LENGTH_SHORT)
//                                    .show();
//                            break;
//
//                        case MotionEvent.ACTION_MOVE:
//                            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) view
//                                    .getLayoutParams();
////                            layoutParams.leftMargin = x - xDelta;
////                            layoutParams.topMargin = y - yDelta;
////                            layoutParams.rightMargin = 0;
////                            layoutParams.bottomMargin = 0;
////                            view.setTranslationX(xDelta);
////                            view.setTranslationY(yDelta);
//                            view.animate().translationXBy(xDelta);
////                            view.animate().translationYBy(yDelta);
////                            layoutParams.leftMargin -= xDelta;
////                            layoutParams.topMargin-= yDelta;
////                            layoutParams.rightMargin += xDelta;
////                            layoutParams.bottomMargin +=yDelta;
//                            view.setLayoutParams(layoutParams);
//                            break;
//                    }
//                    mainLayout.invalidate();
//                    return true;
//                }
//            };
//        }
//        //End copied code This ended up not working properly.

    }

    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    //!!!!!!THIS MAY NEED TO BE REPLACED WITH FragmentStatePagerAdapter
    public class SectionsPagerAdapter extends FragmentStatePagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }
        private LinearLayout sOtherPlayers;

        @Override
        public Fragment getItem(int position) {
            // getItem is called ato instantiate the fragment for the given page.
            // Return a PlaceholderFragment (defined as a static inner class below).
            return PlaceholderFragment.newInstance(position + 1);
        }
        public void setsOtherPlayers(LinearLayout l){
            sOtherPlayers=l;
        }
        @Override
        public int getCount() {
            // Show NUMPAGES total pages.
            return NUMPAGES;
        }



    }
}
