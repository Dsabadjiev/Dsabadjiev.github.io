/*@author: Daniel Abadjiev
 * @date: 6/17/18
 * This is the object used for playing an animated game war.
 */
package com.example.daniela.simplecards;

import android.view.animation.Animation;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.TextView;

public class AnimaWarObj extends WarObject{
    private ImageView p1Card, p2Card;
    private Animation playLeft, playRight;
    private Animation takeLeftToLeft, takeLeftToRight, takeRightToLeft, takeRightToRight;
    private ImageSwitcher p1Card2, p2Card2;
    //This is the constructor which takes in TextView where the game displays the scores of the
    //two players. It also takes in the animations
    public AnimaWarObj(String p1Name, String p2Name, TextView txtOutput, TextView p1Output,
                     TextView p2Output, ImageView p1Cardy, ImageView p2Cardy,
                       Animation takeLeftToLeft, Animation takeLeftToRight, Animation takeRightToLeft,
                       Animation takeRightToRight, Animation playLeft, Animation playRight){
        super(p1Name, p2Name, txtOutput, p1Output, p2Output);
        p1Card=p1Cardy;
        p2Card=p2Cardy;
        this.takeLeftToLeft=takeLeftToLeft;
        this.takeLeftToRight=takeLeftToRight;
        this.takeRightToLeft=takeRightToLeft;
        this.takeRightToRight=takeRightToRight;
        this.playLeft=playLeft;
        this.playRight=playRight;


    }
    //This is the constructor which takes in TextView where the game displays the scores of the
    //two players. It also takes in the animations. It takes in ImageSwitchers instead of ImageViews
    public AnimaWarObj(String p1Name, String p2Name, TextView txtOutput, TextView p1Output,
                       TextView p2Output, ImageSwitcher p1Cardy, ImageSwitcher p2Cardy,
                       Animation takeLeftToLeft, Animation takeLeftToRight, Animation takeRightToLeft,
                       Animation takeRightToRight, Animation playLeft, Animation playRight){
        super(p1Name, p2Name, txtOutput, p1Output, p2Output);
        p1Card2=p1Cardy;
        p2Card2=p2Cardy;
        this.takeLeftToLeft=takeLeftToLeft;
        this.takeLeftToRight=takeLeftToRight;
        this.takeRightToLeft=takeRightToLeft;
        this.takeRightToRight=takeRightToRight;
        this.playLeft=playLeft;
        this.playRight=playRight;


    }
    //This is the constructor which takes in TextView where the game displays the scores of the
    //two players.
    public AnimaWarObj(String p1Name, String p2Name, TextView txtOutput, TextView p1Output,
                       TextView p2Output, ImageView p1Cardy, ImageView p2Cardy){
        super(p1Name, p2Name, txtOutput, p1Output, p2Output);
        p1Card=p1Cardy;
        p2Card=p2Cardy;



    }
    //This is the method to play one round (per war rules)
    public void round(){
        if (p1.getSize()==0) {
            mainOutput.setText(mainOutput.getText() + "\n" + p2.getName() + " won the game.");

        }
        else if (p2.getSize()==0)
            mainOutput.setText(mainOutput.getText()+"\n"+p1.getName()+" won the game.");
        else{

            exchangeCards(p1, p2, table, mainOutput, p1Card, p2Card, takeLeftToLeft,
                    takeLeftToRight, takeRightToLeft,takeRightToRight, playLeft,playRight);
            p1Score.setText(p1.getName()+" has "+p1.getSize()+" cards.");
            p2Score.setText(p2.getName()+" has "+p2.getSize()+" cards.");
//            p1Card.setImageResource(R.drawable.blue_back);
//            p2Card.setImageResource(R.drawable.blue_back);
            p1.shuffle();
            p2.shuffle();
        }
        InteractiveWar.scrollDown(mainOutput);
    }
    //This is the method to exchange cards between to players via war rules.
    public static void exchangeCards(Hand p1, Hand p2, Hand table, TextView txtOutput,
                                     ImageView p1Card, ImageView p2Card, Animation takeLeftToLeft,
                                     Animation takeLeftToRight, Animation takeRightToLeft,
                                     Animation takeRightToRight, Animation playLeft,
                                     Animation playRight) {
//        txtOutput.append("HELLOW WORLD"+p1.cardAt(0).getCardPic()); //Testing purposes

        p1Card.setImageResource(p1.cardAt(0).getCardPic());

        p2Card.setImageResource(p2.cardAt(0).getCardPic());
        txtOutput.setText(txtOutput.getText() + "\n" + p1.getName() + " plays " + p1.cardAt(0) +
                " and " + p2.getName() + " plays " + p2.cardAt(0));
        if (p1.cardAt(0).compareTo(p2.cardAt(0)) > 0) {
            Hand.switchCard(p1, p2, p2.cardAt(0));
            Hand.switchCards(p1, table);
            txtOutput.setText(txtOutput.getText() + "\n" + p1.getName() + " won the round.");
            p1Card.startAnimation(takeLeftToLeft);
            p2Card.startAnimation(takeRightToLeft);

        } else if (p1.cardAt(0).compareTo(p2.cardAt(0)) < 0) {
            Hand.switchCard(p2, p1, p1.cardAt(0));
            Hand.switchCards(p2, table);
            txtOutput.setText(txtOutput.getText() + "\n" + p2.getName() + " won the round.");
            p1Card.startAnimation(takeLeftToRight);
            p2Card.startAnimation(takeRightToRight);

        } else {
            p1Card.startAnimation(playLeft);
            p2Card.startAnimation(playRight);
            txtOutput.append("\nWAR!!!\n3 cards from each player down on the table.");
            if (p1.getSize() < 7)
                Hand.switchCards(p2, p1);
            else if (p2.getSize() < 7)
                Hand.switchCards(p1, p2);
            else {
                for (int i = 0; i < 4; i++) {
                    Hand.switchCard(table, p1, p1.cardAt(i));
                    Hand.switchCard(table, p2, p2.cardAt(i));
                }
                exchangeCards(p1, p2, table, txtOutput, p1Card, p2Card, takeLeftToLeft,
                        takeLeftToRight, takeRightToLeft,takeRightToRight, playLeft,playRight);
            }
        }


    }
    //This is the method to exchange cards between to players via war rules.
    public static void exchangeCards(Hand p1, Hand p2, Hand table, TextView txtOutput,
                                     ImageSwitcher p1Card, ImageSwitcher p2Card, Animation takeLeftToLeft,
                                     Animation takeLeftToRight, Animation takeRightToLeft,
                                     Animation takeRightToRight, Animation playLeft,
                                     Animation playRight) {
//        txtOutput.append("HELLOW WORLD"+p1.cardAt(0).getCardPic()); //Testing purposes

        p1Card.setImageResource(p1.cardAt(0).getCardPic());

        p2Card.setImageResource(p2.cardAt(0).getCardPic());
        txtOutput.setText(txtOutput.getText() + "\n" + p1.getName() + " plays " + p1.cardAt(0) +
                " and " + p2.getName() + " plays " + p2.cardAt(0));
        if (p1.cardAt(0).compareTo(p2.cardAt(0)) > 0) {
            Hand.switchCard(p1, p2, p2.cardAt(0));
            Hand.switchCards(p1, table);
            txtOutput.setText(txtOutput.getText() + "\n" + p1.getName() + " won the round.");
            p1Card.startAnimation(takeLeftToLeft);
            p2Card.startAnimation(takeRightToLeft);

        } else if (p1.cardAt(0).compareTo(p2.cardAt(0)) < 0) {
            Hand.switchCard(p2, p1, p1.cardAt(0));
            Hand.switchCards(p2, table);
            txtOutput.setText(txtOutput.getText() + "\n" + p2.getName() + " won the round.");
            p1Card.startAnimation(takeLeftToRight);
            p2Card.startAnimation(takeRightToRight);

        } else {
            p1Card.startAnimation(playLeft);
            p2Card.startAnimation(playRight);
            txtOutput.append("\nWAR!!!\n3 cards from each player down on the table.");
            if (p1.getSize() < 7)
                Hand.switchCards(p2, p1);
            else if (p2.getSize() < 7)
                Hand.switchCards(p1, p2);
            else {
                for (int i = 0; i < 4; i++) {
                    Hand.switchCard(table, p1, p1.cardAt(i));
                    Hand.switchCard(table, p2, p2.cardAt(i));
                }
                exchangeCards(p1, p2, table, txtOutput, p1Card, p2Card, takeLeftToLeft,
                        takeLeftToRight, takeRightToLeft, takeRightToRight, playLeft, playRight);
            }
        }
    }
}
