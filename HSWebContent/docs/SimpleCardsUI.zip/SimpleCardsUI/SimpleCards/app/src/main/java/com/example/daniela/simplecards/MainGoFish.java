/*@author: Daniel Abadjiev
 * @date: 6/10/18
 * This is the runner class for go fish
 */
package com.example.daniela.simplecards;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainGoFish extends AppCompatActivity {
    TextView output, viewCards;
    EditText inputCard, inputName;
    Button next, swich;
    GoFish game;
    @Override
    //This is the equivalent of the main method for this class
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_go_fish);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Go Fish");
        output=(TextView) findViewById(R.id.output);
        output.setMovementMethod(new ScrollingMovementMethod());
        viewCards=(TextView) findViewById(R.id.cardView);
        viewCards.setMovementMethod(new ScrollingMovementMethod());
        inputCard= (EditText) findViewById(R.id.inputCard);
        inputName= (EditText) findViewById(R.id.inputName);
        inputName.setText("<Number of Players>");
        next=(Button) findViewById(R.id.next);
        swich=(Button) findViewById(R.id.buttSwitch);

        output.setText("Please enter the number of players, then press start new game.");
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }
    //This is the method for the button which starts a new game.
    public void newGame(View v){

        String sNumPlayers=inputName.getText().toString();

        int numPlayers=0;
        try  {
            numPlayers = Integer.parseInt(sNumPlayers);
        }
        catch (NumberFormatException e) {
            output.setText("Please correctly enter a valid number of players, then press start.");
        }
        if (numPlayers<=0)
            output.setText("Please correctly enter a valid number of players, then press start.");
        else{
//            output.append(sNumPlayers+" or "+numPlayers+" are playing now."); Testing purposes
            game=new GoFish(output, inputName, inputCard, numPlayers, viewCards, next, swich);
            game.play(output);
        }
        InteractiveWar.scrollDown(output);
    }


}
