package com.example.daniela.simplecards;

import com.example.daniela.simplecards.Card;

import java.util.ArrayList;

/*@author: Daniel Abadjiev
 * @date: 5/21/18
 * This is the template for a regular deck.
 */

public class Deck {
	protected ArrayList<Card> cards;
	//This is the default constructor which constructs a standard deck of 52 cards.
	public Deck(){
		cards=new ArrayList<Card>();
		for (int i=0; i<=3; i++) {
			for (int j=1; j<=13; j++) {
				Card nextCard=new Card(j, Card.numToSuit(i));
				cards.add(nextCard);
			}
		}
	}
	//This constructs a custom deck
	public Deck(ArrayList<Card> c){
		cards=c;
	}
//	public int indexOf(Card card) {Testing purposes, redundant/useless method.
//		return cards.indexOf(card);
//	}
	//This returns the index of a passed card in this deck
	public int indexOf(Card card){
		for (int i=0; i<cards.size(); i++){
//			System.out.println(cards.get(i)+", "+card+", "+cards.get(i).equals(card));
// ^^Testing purposes
			if (cards.get(i).equals(card))
				return i;
		}
		return -1;
	}
	//This is like the substring method, and returns a deck which is a subset of this deck
	public Deck subDeck(int start, int end){
		ArrayList<Card> c=new ArrayList<Card>();
		for (int i=start; i<end; i++){
			c.add(cards.get(i));
		}
		return new Deck(c);
	}
	//This is like the substring method, and returns a hand which is a subset of this deck, with the
	//passed name.
	public Hand subHand(int start, int end, String name){
		ArrayList<Card> c=new ArrayList<Card>();
		for (int i=start; i<end; i++){
			c.add(cards.get(i));
		}
		return new Hand(c, name);
	}
	//These are the getters for size and cards.
	public int getSize(){
		return cards.size();
	}

    public ArrayList<Card> getCards() {
        return cards;
    }
	//This is like the charAt() method in String, and returns the card at a certain index.
    public Card cardAt(int num) {
		return cards.get(num);
	}
	//This shuffles this deck.
	public void shuffle() {
		ArrayList<Card> nextArray=new ArrayList<Card>(0);
		for (int i=0; i<cards.size();) {
			int rand=(int) (Math.random()*cards.size());
			nextArray.add(this.cardAt(rand));
			cards.remove(rand);
			
		}
		cards=nextArray;
	}
	//This returns a shuffled form of a passed deck.
	public static Deck shuffle(Deck d){
        ArrayList<Card> nextArray=new ArrayList<Card>(0);
        for (int i=0; i<d.getSize();) {
            int rand=(int) (Math.random()*d.getCards().size());
            nextArray.add(d.cardAt(rand));
            d.getCards().remove(rand);

        }
        return new Deck(nextArray);
    }
	

}
