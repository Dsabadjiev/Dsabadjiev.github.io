package com.example.daniela.simplecards;

import android.widget.ImageView;

public class CardWithImage {
    private Card c;
    private ImageView i;
    private int resourceID;
    public CardWithImage(Card c, ImageView i, int rID){
        this.c=c;
        this.i=i;
        resourceID=rID;
    }
    public CardWithImage(Card c, ImageView i){
        this.c=c;
        this.i=i;
    }
    public ImageView getI() {
        return i;
    }

    public void setI(ImageView i) {
        this.i = i;
    }

    public Card getC() {
        return c;
    }

    public void setC(Card c) {
        this.c = c;
    }

    public int getResourceID() {
        return resourceID;
    }

    public void setResourceID(int resourceID) {
        this.resourceID = resourceID;
    }
}
