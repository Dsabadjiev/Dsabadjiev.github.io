///*@author: Daniel Abadjiev
// * @date: 5/31/18
// * This is a class to play the card game War, now more interactively.
// */
//This class did not work as intended, as there were a lot of problems with it, so I took a
// different approach
//and scrapped this, though some things were used as the basis of implementation for the next
//version of the class.
//package com.example.daniela.simplecards;
//
//import android.support.design.widget.FloatingActionButton;
//import android.support.design.widget.Snackbar;
//import android.view.View;
//import android.widget.TextView;
//
//import java.util.ArrayList;
//
//public class War2 implements Game{
//	private static int numPress=0;
//	public static void main(String[] args) {
//
////		Deck deck=new Deck();
////		Hand player1=deck.subHand(0, deck.getSize()/2, "p1");
////		Hand player2=deck.subHand(deck.getSize()/2, deck.getSize(), "p2");
//////		ArrayList<Card> p1Cards=new ArrayList<Card>(), p2Cards=new ArrayList<Card>();
////		txtOutput.setText(txtOutput.getText()+"\nnew War().play()+" has won the game.");
//
//
//
//	}
//
//	public String play(TextView txtOutput){
//		Deck deck=Deck.shuffle(new Deck());
//		Hand p1=deck.subHand(0, deck.getSize()/2, "p1");
//		Hand p2=deck.subHand(deck.getSize()/2, deck.getSize(), "p2");
//		deck.shuffle();
//
//		Hand table=new Hand(new ArrayList<Card>(), "table");
//		p1.shuffle();
//		p2.shuffle();
//
//		txtOutput.setText(txtOutput.getText()+"\n"+p1.getName()+" has "+p1.getSize()+" cards.");
//		txtOutput.setText(txtOutput.getText()+"\n"+p2.getName()+" has "+p2.getSize()+" cards.");
//		while (p1.getSize()>0 && p2.getSize()>0){
//			txtOutput.setText(txtOutput.getText()+"\n"+p1.getName()+" plays "+p1.cardAt(0)+" and
// "+p2.getName()+" plays "+p2.cardAt(0));
//
//			exchangeCards(p1, p2, table, txtOutput);
////			Hand.switchCard(p1, p2, p2.cardAt(0));
//			System.out.print("Now ");
//			txtOutput.setText(txtOutput.getText()+"\n"+p1.getName()+" has "+p1.getSize()+" cards.");
//			txtOutput.setText(txtOutput.getText()+"\n"+p2.getName()+" has "+p2.getSize()+" cards.");
//			p1.shuffle();
//			p2.shuffle();
//		}
//		Hand winner;
//		if (p1.getSize()>0)
//			winner=p1;
//		else
//			winner=p2;
//		return winner.getName();
////		txtOutput.setText(txtOutput.getText()+"\n"+winner.getName()+" has won the game!");
//	}
//	Deck deck=Deck.shuffle(new Deck());
//	Hand p1=deck.subHand(0, deck.getSize()/2, "p1");
//	Hand p2=deck.subHand(deck.getSize()/2, deck.getSize(), "p2");
//	public String play(TextView txtOutput, FloatingActionButton fab){
//
////		Deck deck=new Deck();
//		deck.shuffle();
//
//
//		final Hand table=new Hand(new ArrayList<Card>(), "table");
//		p1.shuffle();
//		p2.shuffle();
//
//		txtOutput.setText(txtOutput.getText()+"\n"+p1.getName()+" has "+p1.getSize()+" cards.");
//		txtOutput.setText(txtOutput.getText()+"\n"+p2.getName()+" has "+p2.getSize()+" cards.");
//		fab.setOnClickListener(new View.OnClickListener() {
//			@Override
//			public void onClick(View view) {
//				if (p1.getSize()==0)
//					return;
//				else if (p2.getSize()==0)
//					return;
//				else {
//					ScrollingActivity.txtOutput.setText(txtOutput.getText()+"\n"+p1.getName()+"
// plays "+p1.cardAt(0)+" and "+p2.getName()+" plays "+p2.cardAt(0));
//
//					exchangeCards(p1, p2, table, txtOutput);
////			Hand.switchCard(p1, p2, p2.cardAt(0));
//					System.out.print("Now ");
//					txtOutput.setText(txtOutput.getText()+"\n"+p1.getName()+" has "+p1.getSize()+" cards.");
//					txtOutput.setText(txtOutput.getText()+"\n"+p2.getName()+" has "+p2.getSize()+" cards.");
//					p1.shuffle();
//					p2.shuffle();
//				}
//			}
//		});
////		while (p1.getSize()>0 && p2.getSize()>0){
////			txtOutput.setText(txtOutput.getText()+"\n"+p1.getName()+" plays "+p1.cardAt(0)+"
/// and "+p2.getName()+" plays "+p2.cardAt(0));
////
////			exchangeCards(p1, p2, table, txtOutput);
//////			Hand.switchCard(p1, p2, p2.cardAt(0));
////			System.out.print("Now ");
////			txtOutput.setText(txtOutput.getText()+"\n"+p1.getName()+" has "+p1.getSize()+" cards.");
////			txtOutput.setText(txtOutput.getText()+"\n"+p2.getName()+" has "+p2.getSize()+" cards.");
////			p1.shuffle();
////			p2.shuffle();
////		}
//		Hand winner;
//		if (p1.getSize()>0)
//			winner=p1;
//		else
//			winner=p2;
//		return winner.getName();
////		txtOutput.setText(txtOutput.getText()+"\n"+winner.getName()+" has won the game!");
//	}
//	public void buttonClick(View v){
//		numPress++;
////		TextView txtOutput=(TextView) findViewById(R.id.txt);
//		if (p1.getSize()==0)
//			return;
//		else if (p2.getSize()==0)
//			return;
//		else{
//
//		}
////Does nothing for now
//	}
//	public static void exchangeCards(Hand p1, Hand p2, Hand table, TextView txtOutput){
//		if (p1.cardAt(0).compareTo(p2.cardAt(0))>0){
//			Hand.switchCard(p1, p2, p2.cardAt(0));
//			Hand.switchCards(p1, table);
//			txtOutput.setText(txtOutput.getText()+"\n"+p1.getName()+" won the round");
//		}
//		else if (p1.cardAt(0).compareTo(p2.cardAt(0))<0){
//			Hand.switchCard(p2, p1, p1.cardAt(0));
//			Hand.switchCards(p2, table);
//			txtOutput.setText(txtOutput.getText()+"\n"+p2.getName()+" won the round");
//		}
//		else{
//			if (p1.getSize()<6)
//				Hand.switchCards(p2,  p1);
//			else if (p2.getSize()<6)
//				Hand.switchCards(p1, p2);
//			else{
//			for (int i=0; i<4; i++){
//				Hand.switchCard(table, p1, p1.cardAt(i));
//				Hand.switchCard(table, p2, p2.cardAt(i));
//			}
//			exchangeCards(p1, p2, table, txtOutput);
//			}
//		}
//
//	}
////	public static void round(Hand p1, Hand p2){
////		txtOutput.setText(txtOutput.getText()+"\np1.getName()+" has "+p1.getSize()+" cards.");
////		txtOutput.setText(txtOutput.getText()+"\np2.getName()+" has "+p2.getSize()+" cards.");
////		while (p1.getSize()>0 && p2.getSize()>0){
////			txtOutput.setText(txtOutput.getText()+"\np1.getName()+" plays "+p1.cardAt(0)+" and "
/// +p2.getName()+" plays "+p2.cardAt(0));
////			Hand.switchCard(p1, p2, p2.cardAt(0));
////			System.out.print("Now ");
////			txtOutput.setText(txtOutput.getText()+"\np1.getName()+" has "+p1.getSize()+" cards.");
////			txtOutput.setText(txtOutput.getText()+"\np2.getName()+" has "+p2.getSize()+" cards.");
////		}
////		Hand winner;
////		if (p1.getSize()>0)
////			winner=p1;
////		else
////			winner=p2;
////		txtOutput.setText(txtOutput.getText()+"\nwinner.getName()+" has won the game!");
////
////	}
//
//}
