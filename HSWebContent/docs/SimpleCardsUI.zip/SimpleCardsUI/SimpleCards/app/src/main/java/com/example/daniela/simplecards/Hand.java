/*@author: Daniel Abadjiev
 * @date: 5/22/18
 * This is the template for hand that a player can hold.
 */
package com.example.daniela.simplecards;
import com.example.daniela.simplecards.Card;
import com.example.daniela.simplecards.Deck;

import java.util.*;

public class Hand extends Deck {
	private String name;
	//This is the constructor which takes in the cards and the name of the hand (or player).
	public Hand(ArrayList<Card> input, String namey) {
		super();
		cards=new ArrayList<Card>();
		cards=input;
		name=namey;
	}
	//This was a testing method to make it easy to input a hand in eclipse.
	public Hand(Scanner console) {
		System.out.println("What is the name of this Hand");
		name=console.nextLine();
		cards=inputCards(console);
		
	}
	//This is the default constructor, which makes the hand have all 52 cards, and no name.
	public Hand(){
		super();
	}
	//These are the getters for cards and name
	public ArrayList<Card> getCards(){
		return cards;
	}
	public String getName(){
		return name;
	}
	//This is the toString method which returns the toString of cards.
	public String toString(){
		return cards.toString();
	}
	//This remove a passed card from a hand, and returns the card removed, null if no card is removed.
	public Card removeCard(Card c) {
		int index=indexOf(c);
		if (index<0){
			return null;
		}
		Card c2=cards.get(index);
//		System.out.println(c2); Testing purpoises
		cards.remove(index);
		return c2;
	}
	//This returns the card at a certain index, and removes that card from the hand.
	public Card removeCard(int index) {

		if (index<0 || index>=cards.size()){
			return null;
		}
		Card c2=cards.get(index);
//		System.out.println(c2); Testing purpoises
		cards.remove(index);
		return c2;
	}
	//This adds a card to a hand
	public void addCard(Card c) {
		cards.add(c);
	}
	//This switches one card from the second hand to the first.
	public static boolean switchCard(Hand h1, Hand h2, Card c) {
		Card c2=h2.removeCard(c);
//		System.out.println(c2); Testing purpoises
		if (c2==null)
			return false;
		h1.addCard(c2);
		return true;
	}
	//This switches all cards from the second hand to the first.
	public static void switchCards(Hand h1, Hand h2){
		while (h2.getSize()>0){
			switchCard(h1, h2, h2.cardAt(0));
		}
	}
	//This was for testing in eclipse, and gets the cards from the console
	public static ArrayList<Card> inputCards(Scanner console){
		System.out.println("Please enter the cards in the form \"[value] of [suit]\". ");
		System.out.println("For example,\"Ace of Hearts\" or \"2 of Clubs\"");
		System.out.println("Valid suits are Spades, Hearts, Diamonds, and Clubs");
		System.out.println("Valid values can either be an integer (1 is ace, King is 13)");
		System.out.println("or \"Ace\" or \"Queen\", \"King\", or \"Jack\".");
		System.out.println("What is the first card?");
		ArrayList<Card> arr=new ArrayList<Card>();
//		String card=console.nextLine(); Testing purposes
//		System.out.println(card); Testing purposes
		arr.add(new Card(console.nextLine()));
		while (hasMore(console)) {
			System.out.println("What is the next card?");
			arr.add(new Card(console.nextLine()));
		}
		System.out.println("Your hand is now "+arr);
		return arr;
		
	}
	//This is a helper method for the above method, and asks the user if they have more cards.
	public static boolean hasMore(Scanner console) {
		System.out.println("Are there more cards?");
		String answer=console.nextLine();
		if (answer.toLowerCase().charAt(0)=='y')
			return true;
		else
			return false;
	}
	//This returns hand of a player with certain name that is in an ArrayList<Hand>
	public static Hand findPlayer(String name, ArrayList<Hand> hands){
		for (int i=0; i<hands.size(); i++){
			if (hands.get(i).getName().equals(name))
				return hands.get(i);
		}
		return null;
	}


}
