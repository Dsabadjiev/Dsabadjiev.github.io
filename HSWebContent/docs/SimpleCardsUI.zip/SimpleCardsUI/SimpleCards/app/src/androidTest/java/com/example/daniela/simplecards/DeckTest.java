package com.example.daniela.simplecards;

import static org.junit.Assert.*;

public class DeckTest {

}