/*@author: Daniel Abadjiev
 * @date: 5/21/18
 * This is the template for each individual card
 */
package com.example.daniela.simplecards;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;

import java.util.Arrays;

public class Card {
	//Value is between 1 and 13, inclusive

	private int value;
	//"spades", "hearts", "diamonds", or "clubs"
	private String suit;
	private String stringValue;
	public static final String[] SUITS= {"spades", "hearts", "diamonds", "clubs"};
	//I used a seperate java file in eclipse to compile a string for the body of this array.
	//I got the images from the internet, http://acbl.mybigcommerce.com/52-playing-cards/,
	// but I did have to go through all of them and rename them,
	//because they cannot have capital letters, and must begin with
	public static final int[] IMGREFERENCE = {
			R.drawable.cas, R.drawable.c2s, R.drawable.c3s, R.drawable.c4s, R.drawable.c5s,
			R.drawable.c6s, R.drawable.c7s, R.drawable.c8s, R.drawable.c9s, R.drawable.c10s,
			R.drawable.js, R.drawable.qs, R.drawable.ks,
			R.drawable.cah, R.drawable.c2h, R.drawable.c3h, R.drawable.c4h, R.drawable.c5h,
			R.drawable.c6h, R.drawable.c7h, R.drawable.c8h, R.drawable.c9h, R.drawable.c10h,
			R.drawable.jh, R.drawable.qh, R.drawable.kh,
			R.drawable.cad, R.drawable.c2d, R.drawable.c3d, R.drawable.c4d, R.drawable.c5d,
			R.drawable.c6d, R.drawable.c7d, R.drawable.c8d, R.drawable.c9d, R.drawable.c10d,
			R.drawable.jd, R.drawable.qd, R.drawable.kd,
			R.drawable.cac, R.drawable.c2c, R.drawable.c3c,
			R.drawable.c4c, R.drawable.c5c, R.drawable.c6c, R.drawable.c7c, R.drawable.c8c,
			R.drawable.c9c, R.drawable.c10c, R.drawable.jc, R.drawable.qc, R.drawable.kc
	};
	public static final String NUMREFERENCE="0123456789";
	//Change 12/16/18, added one instance variable to represent ImageView asscoiated with a card.
	private ImageView img;
	//This constructor makes a card from a value and a suit.
	public Card(int val, String suity) {
		value=val;
		stringValue=valToString(value);
		suit=suity;
			
	}
	//This is the constructor that makes the card from an inputted string.
	public Card(String s) {
//		stringValue=s.substring(0, s.indexOf(" ")); Testing purposes
		s=s.toLowerCase();
		suit=s.substring(s.indexOf("of")+3);
//		System.out.println(s.substring(0, s.indexOf(" "))); Testing purposes
		value=stringValToInt(s.substring(0, s.indexOf(" ")));
//		System.out.println(value); Testing purposes
		stringValue=valToString(value);
	}
	//This is used for comparing values for war.
	public int compareTo( Card c2){
		return this.value-c2.value;
	}
	//This converts an integer value into the appropriate string.
	public static String valToString(int val) {
		if (val==1)
			return "ace";
		else if (val<11) 
			return ""+val;
		else if (val==11)
			return "jack";
		else if (val==12)
			return "queen";
		else if (val==13)
			return "king";
		else return "";
	}
	//This converts a string value into the appropriate int.
	public static int stringValToInt(String stringVal) {
		if (stringVal.length()==1) {
			return NUMREFERENCE.indexOf(stringVal);
		}
		else if (stringVal.length()==2) {
			return Integer.parseInt(stringVal);
		}
		else if(stringVal.equals("ace"))
			return 1;
		else if (stringVal.equals("jack"))
			return 11;
		else if (stringVal.equals("queen"))
			return 12;
		else if (stringVal.equals("king"))
			return 13;
		else return 0;
	}
	//This method tests if a string is a valid for the constructor which takes in a string.
	public static boolean isValidCard(String s){
        s=s.toLowerCase();
	    if (s.indexOf("of")<0)
			return false;

		String suit=s.substring(s.indexOf("of")+3);
		int value=stringValToInt(s.substring(0, s.indexOf(" ")));
		return indexOf(SUITS, suit)>=0 && value>0;

	}
	//This returns the index of an object in an array
	public static int indexOf(Object[] arr, Object o){
		for (int i=0; i<arr.length; i++)
			if (o.equals(arr[i]))
				return i;
		return -1;
	}
	public static int indexOf(int[] arr, int o){
		for (int i=0; i<arr.length; i++)
			if (o == (arr[i]))
				return i;
		return -1;
	}
	//This returns the string that corresponds to this card.
	public String toString() {
		return capitalize(this.stringValue) +" of "+capitalize(this.suit);
	}
	//This fixes the string into a file name.
	public String toFileString(){
		String s="";
		if (this==null)
			return "gray_back";
		else if (value==10)
			s+=10;
		else
			s+=stringValue.toLowerCase().charAt(0);
		s+=suit.toLowerCase().charAt(0);
		s="c"+s;
		return s;
	}
	//This returns the int that corresponds to the Drawable that corresponds to this card.
	public int getCardPic(){
		//I got the idea for how to implement this setting of images from the internet.
		int i=indexOf(SUITS, suit);
		int j=value;
		return IMGREFERENCE[i*13+j-1];
	}

	//added new constructor 12/16/18
	public Card(int resource){
		int index=indexOf(IMGREFERENCE, resource);
		if (index==-1)
			return;
		suit=numToSuit(index/13);
		value=index%13+1;
		stringValue=valToString(value);

	}

	//This capitalizes the first letter of a string.
	public static String capitalize(String s){
		return s.substring(0,1).toUpperCase()+s.substring(1);
	}
	//This tests if two cards are equal
	public boolean equals(Card c){
		return this.toString().equals(c.toString());
	}
	//This returns the string suit for a corresponding integer.
	public static String numToSuit(int num) {
		return SUITS[num];
	}
	//These are the getters for value, stringValue, and suit.
	public int getValue() {
		return value;
	}
	public String getStringValue() {
		return stringValue;
	}
	public String getSuit() {
		return suit;
	}



	public ImageView getImg() {
		return img;
	}

	public void setImg(ImageView img) {
		this.img = img;
	}
}
