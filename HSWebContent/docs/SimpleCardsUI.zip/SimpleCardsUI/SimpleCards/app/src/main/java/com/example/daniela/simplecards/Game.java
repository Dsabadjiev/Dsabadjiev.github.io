/*@author:Daniel Abadjiev
 * @date: 5/29/18
 * This is the interface for a general game.
 */
package com.example.daniela.simplecards;

import android.widget.TextView;

public interface Game {
	//This is the standard, default method for playing a game that every game must have.
	//The method must return a winner, if applicable, and otherwise should return ""
	public String play(TextView txtOutput);
	
	

}
