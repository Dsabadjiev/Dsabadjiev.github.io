/*@author: Daniel Abadjiev
 * @date: 6/17/18
 * This is the class used for running the animated game war.
 */
package com.example.daniela.simplecards;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.TextView;

public class AnimatedWar extends AppCompatActivity {
    public TextView txtOutput;
    public WarObject war;
    public TextView p1IOutput, p2IOutput;
    public EditText input;
    public ImageView p1Card, p2Card;
    public ImageSwitcher p1Card2, p2Card2;
    public Animation takeLeftToLeft, takeLeftToRight, takeRightToLeft, takeRightToRight;
    public Animation playLeft, playRight;
    public AnimationDrawable setBack;
    @Override
    //This is the equivalent of the main method.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animated_war);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Animated War");
        txtOutput=(TextView) findViewById(R.id.txt2);
        txtOutput.setMovementMethod(new ScrollingMovementMethod());
        p1IOutput=(EditText) findViewById(R.id.p1Output2);
        p2IOutput=(EditText) findViewById(R.id.p2Output2);
        p1IOutput.setText("<Player 1 Name>");
        p2IOutput.setText("<Player 2 Name>");
        txtOutput.setText("Set the players' names then hit start new game to start.");
        String p1Name=p1IOutput.getText().toString();
        p1Card=(ImageView) findViewById(R.id.p1Card);
        p2Card=(ImageView) findViewById(R.id.p2Card);
        //I got this animation stuff from www.tutorialspoint
        playLeft= AnimationUtils.loadAnimation(getApplicationContext(), R.anim.play_left);
//        p1Card.startAnimation(playLeft); //Testing purposes
        playRight= AnimationUtils.loadAnimation(getApplicationContext(), R.anim.play_right);
        takeLeftToLeft=AnimationUtils.loadAnimation(getApplicationContext(), R.anim.take_left_to_left);
//        p1Card.startAnimation(takeLeftToLeft); //Testing purposes
        takeLeftToRight=AnimationUtils.loadAnimation(getApplicationContext(), R.anim.take_left_to_right);
//        p1Card.startAnimation(takeLeftToRight); //Testing purposes
        takeRightToRight=AnimationUtils.loadAnimation(getApplicationContext(), R.anim.take_right_to_right);
        takeRightToLeft=AnimationUtils.loadAnimation(getApplicationContext(), R.anim.take_right_to_left);
        p1Card.setImageResource(R.drawable.blue_back);
        p2Card.setImageResource(R.drawable.blue_back);
//        p1Card.setBackgroundResource(R.drawable.set_back);
//        setBack=(AnimationDrawable) p1Card.getBackground();




//        txtOutput.setText(txtOutput.getText()+"\nHellow World??? And let's see what this does.");
// ^^Testing purposes


//        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
//        new War2().play(txtOutput, fab);     This became irrelevant with new class definitions
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });
    }
    //This is the method that makes the proceed button work.
    public void buttonClick(View v)  {
        if (war !=null) {
            war.round();
//            wait(60000);
//            setBack.start();
        }
    }
    //This makes a TextView object scroll so that the bottom line is visible.
    public static void scrollDown(TextView v){
        if (v !=null){
            //I got the code for this method from Stack Overflow
            // (not including the initial if statement)
            int scrollAmount= v.getLayout().getLineTop(v.getLineCount()) - v.getHeight();
            if (scrollAmount >0)
                v.scrollTo(0, scrollAmount);
            else
                v.scrollTo(0,0);
        }
    }
    //This is the method for the button which starts a new game.
    public void newGame(View v){
//        txtOutput.setText(""); Testing purposes
//        p1Output.setText(""); Testing purposes
//        p2Output.setText("");Testing purposes
        String p1Name=p1IOutput.getText().toString();
        String p2Name=p2IOutput.getText().toString();
        Button b=(Button) findViewById(R.id.proceed2);
        b.setVisibility(View.VISIBLE);
        war=new AnimaWarObj(p1Name, p2Name, txtOutput, p1IOutput, p2IOutput, p1Card, p2Card,
                takeLeftToLeft,takeLeftToRight,takeRightToLeft,takeRightToRight,playLeft,playRight);
        InteractiveWar.scrollDown(txtOutput);
        //I need to add something to scroll up.
    }
    ///This is the method for the button which resets the game.
    public void reset(View v){
        p1IOutput.setText("<Player 1 Name>");
        p2IOutput.setText("<Player 2 Name>");
        txtOutput.setText("Set the players' names then hit start new game to start.");
        InteractiveWar.scrollDown(txtOutput);
        //The above method also works to reset the scrolling (so txt is in right place).
        Button b=(Button) findViewById(R.id.proceed2);
        b.setVisibility(View.INVISIBLE);
    }

}
