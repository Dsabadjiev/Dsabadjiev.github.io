/*@author: Daniel Abadjiev
 * @date: 6/5/18
 * This is a class to play the card game War. This is the final version of the class.
 */
package com.example.daniela.simplecards;

import android.widget.TextView;

import java.util.ArrayList;

public class WarObject implements Game{
	protected Deck deck=new Deck();
	protected Hand p1;
	protected Hand p2;
	protected Hand table=new Hand(new ArrayList<Card>(), "table");
	protected TextView mainOutput, p1Score, p2Score;
	//This is the constructor which takes in just names and the output, used for default play.
	public WarObject(String p1Name, String p2Name, TextView txtOutput){
		deck.shuffle();
		p1=deck.subHand(0, deck.getSize()/2, p1Name);
		p2=deck.subHand(deck.getSize()/2, deck.getSize(), p2Name);
		p1.shuffle();
		p2.shuffle();
		mainOutput=txtOutput;
		mainOutput.setText("You are now playing the game war.");


	}
	//This is the constructor which takes in TextView where the game displays the scores of the
	//two players.
	public WarObject(String p1Name, String p2Name, TextView txtOutput, TextView p1Output,
					 TextView p2Output){
		deck.shuffle();
		p1=deck.subHand(0, deck.getSize()/2, p1Name);
		p2=deck.subHand(deck.getSize()/2, deck.getSize(), p2Name);
		p1.shuffle();
		p2.shuffle();
//		mainOutput=new TextView(); unnecessary
		mainOutput=txtOutput;
		mainOutput.setText("You are now playing the game war. Press the button below to proceed.");
		p1Score=p1Output;
		p2Score=p2Output;
		p1Score.setText(p1.getName()+" has "+p1.getSize()+" cards.");
		p2Score.setText(p2.getName()+" has "+p2.getSize()+" cards.");

	}
	//This is the method to play one round (per war rules)
	public void round(){
		if (p1.getSize()==0) {
			mainOutput.setText(mainOutput.getText() + "\n" + p2.getName() + " won the game.");

		}
		else if (p2.getSize()==0)
			mainOutput.setText(mainOutput.getText()+"\n"+p1.getName()+" won the game.");
		else{

			exchangeCards(p1, p2, table, mainOutput);
			p1Score.setText(p1.getName()+" has "+p1.getSize()+" cards.");
			p2Score.setText(p2.getName()+" has "+p2.getSize()+" cards.");
			p1.shuffle();
			p2.shuffle();
		}
		InteractiveWar.scrollDown(mainOutput);
	}
	//This is the method to play a default game
	public String play(TextView txtOutput){
		txtOutput.setText(txtOutput.getText()+"\n"+p1.getName()+" has "+p1.getSize()+" cards.");
		txtOutput.setText(txtOutput.getText()+"\n"+p2.getName()+" has "+p2.getSize()+" cards.");
		while (p1.getSize()>0 && p2.getSize()>0){

			
			exchangeCards(p1, p2, table, txtOutput);
//			Hand.switchCard(p1, p2, p2.cardAt(0)); done before.
			System.out.print("Now ");
			txtOutput.setText(txtOutput.getText()+"\n"+p1.getName()+" has "+p1.getSize()+" cards.");
			txtOutput.setText(txtOutput.getText()+"\n"+p2.getName()+" has "+p2.getSize()+" cards.");
			p1.shuffle();
			p2.shuffle();
		}
		Hand winner;
		if (p1.getSize()>0)
			winner=p1;
		else
			winner=p2;
		return winner.getName();
	}
	//This is the method to exchange cards between to players via war rules.
	public static void exchangeCards(Hand p1, Hand p2, Hand table, TextView txtOutput){
        txtOutput.setText(txtOutput.getText()+"\n"+p1.getName()+" plays "+p1.cardAt(0)+
				" and "+p2.getName()+" plays "+p2.cardAt(0));
		if (p1.cardAt(0).compareTo(p2.cardAt(0))>0){
			Hand.switchCard(p1, p2, p2.cardAt(0));
			Hand.switchCards(p1, table);
			txtOutput.setText(txtOutput.getText()+"\n"+p1.getName()+" won the round.");
		}
		else if (p1.cardAt(0).compareTo(p2.cardAt(0))<0){
			Hand.switchCard(p2, p1, p1.cardAt(0));
			Hand.switchCards(p2, table);
			txtOutput.setText(txtOutput.getText()+"\n"+p2.getName()+" won the round.");
		}
		else{
			txtOutput.append("\nWAR!!!\n3 cards from each player down on the table.");
			if (p1.getSize()<7)
				Hand.switchCards(p2,  p1);
			else if (p2.getSize()<7)
				Hand.switchCards(p1, p2);
			else{
			for (int i=0; i<4; i++){
				Hand.switchCard(table, p1, p1.cardAt(i));
				Hand.switchCard(table, p2, p2.cardAt(i));
			}
			exchangeCards(p1, p2, table, txtOutput);
			}
		}
		
	}
	//THis is the old method that did not work. It is the basis for the above method.
//	public static void round(Hand p1, Hand p2){
//		txtOutput.setText(txtOutput.getText()+"\np1.getName()+" has "+p1.getSize()+" cards.");
//		txtOutput.setText(txtOutput.getText()+"\np2.getName()+" has "+p2.getSize()+" cards.");
//		while (p1.getSize()>0 && p2.getSize()>0){
//			txtOutput.setText(txtOutput.getText()+"\np1.getName()+" plays "+p1.cardAt(0)+" and
// 					"+p2.getName()+" plays "+p2.cardAt(0));
//			Hand.switchCard(p1, p2, p2.cardAt(0));
//			System.out.print("Now ");
//			txtOutput.setText(txtOutput.getText()+"\np1.getName()+" has "+p1.getSize()+" cards.");
//			txtOutput.setText(txtOutput.getText()+"\np2.getName()+" has "+p2.getSize()+" cards.");
//		}
//		Hand winner;
//		if (p1.getSize()>0)
//			winner=p1;
//		else
//			winner=p2;
//		txtOutput.setText(txtOutput.getText()+"\nwinner.getName()+" has won the game!");
//		
//	}

}
